//
//  ViewController.swift
//  Discount Price
//
//  Created by Ahmed Almansor on 8/26/17.
//
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var OrignalPrice: UITextField!
    @IBOutlet weak var Percentage: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

        @IBAction func HowMuch(_ sender: UIButton) {
            OrignalPrice.resignFirstResponder()
            Percentage.resignFirstResponder()
            perform()

        }
    func perform() {
        
        if OrignalPrice.text!.isEmpty {
            if Percentage.text!.isEmpty{
                // please enter percentage
                let alert = UIAlertController(title: "No Input!", message: "Please enter values", preferredStyle: .alert)
                let action = UIAlertAction(title: "Ok", style: .default) {(UIAlertAction) in}
                alert.addAction(action)
                self.present(alert, animated: true, completion: nil)
            }else {
                // alert please enter orignal price
                let alert = UIAlertController(title: "price Empty!", message: "please enter price", preferredStyle: .alert)
                let action = UIAlertAction(title: "Ok", style: .default) {(UIAlertAction) in}
                alert.addAction(action)
                self.present(alert, animated: true, completion: nil)
            }
        }else{
            let discountP = (Percentage.text! as NSString).doubleValue / 100
            let discountAmount = (OrignalPrice.text! as NSString).doubleValue * discountP
            let priceAfter = (OrignalPrice.text! as NSString).doubleValue - discountAmount
            let alert = UIAlertController(title: "Price after discount is: ", message: (String(priceAfter)), preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default) {(UIAlertAction) in}
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
        }

    }
}

